/*tabela para colocar os registos de auditoria*/
CREATE TABLE T1_Audit
(
	ChaveAudit int IDENTITY PRIMARY KEY
	,ChaveAuditPai int
	,NomePKG varchar(100)
	,GuidPKG uniqueidentifier
	,DataExec Date
	,DataInicio Datetime
	,RExtract int
	,RInicio int
	,RFim int
)

/*tabela para carregar no exemplo da aula*/
CREATE TABLE T1_DimProduto
(
	[Chave do Produto] int Primary key
	,[C�digo do Produto] varchar(100)
	,[Nome do Produto] varchar(100)
	,[Categoria do Produto] varchar(100)
)




