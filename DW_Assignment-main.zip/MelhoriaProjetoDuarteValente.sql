/* Tabelas de Dimensao */

CREATE TABLE Cliente( /*Checked*/
	key_cliente INT PRIMARY KEY CLUSTERED not null,
	numero_cliente INT null,
	tipo_cliente VARCHAR(20) null,
	nome VARCHAR(20) null,
	NIF VARCHAR(9) null,
	SASE BIT null,
	Telefone VARCHAR(9) null,
	);

CREATE TABLE Servicos( /*Checked*/
	key_servicos INT PRIMARY KEY CLUSTERED not null,
	designacao VARCHAR(25) null,
	preco DECIMAL(10,2) null,
	gabinete VARCHAR(25) null
	);

CREATE TABLE Produto( /*Checked*/
	key_produto INT PRIMARY KEY CLUSTERED not null,
	designacao VARCHAR(25) null,
	preco DECIMAL(10,2) null,
	stock INT null
);

CREATE TABLE Departamento( /*Checked*/
	key_departamento INT PRIMARY KEY CLUSTERED not null,
	designacao VARCHAR(25) null,
	gabinete VARCHAR(25) null
);

CREATE TABLE Data( /*Checked*/
	key_data INT PRIMARY KEY CLUSTERED not null,
	data_completa DATETIME null,
	dia_semana VARCHAR(20) null,
	);

CREATE TABLE Funcionario( /*Checked*/
	key_funcionario INT PRIMARY KEY CLUSTERED not null,
	nome VARCHAR(25) not null,
	localidade VARCHAR(25) null,
	num_funcionario INT null,
	num_telefone VARCHAR(9) null,
	NIF VARCHAR(9)
	);


	
/* Tabela de Factos */
CREATE TABLE Transacoes(
key_transacoes INT PRIMARY KEY CLUSTERED not null,
key_cliente INT not null,
key_servicos INT not null,
key_produto INT not null,
key_departamento INT not null,
key_data INT not null,
key_funcionario INT not null,
quantidade INT null,
Subtotal INT null,
FOREIGN KEY (key_transacoes) REFERENCES Transacoes(key_transacoes),
FOREIGN KEY (key_departamento) REFERENCES Departamento(key_departamento),
FOREIGN KEY (key_servicos) REFERENCES Servicos(key_servicos),
FOREIGN KEY (key_data) REFERENCES Data(key_data),
FOREIGN KEY (key_produto) REFERENCES Produto(key_produto),
FOREIGN KEY (key_cliente) REFERENCES Cliente(key_cliente),
FOREIGN KEY (key_funcionario) REFERENCES Funcionario(key_funcionario),
);

/*ELIMINAR TODAS AS TABELAS*/

DROP TABLE Transacoes

DROP TABLE Cliente
DROP TABLE Data
DROP TABLE Departamento
DROP TABLE Funcionario
DROP TABLE Produto
DROP TABLE Servicos














/* Adicionar dados a Tabela de Departamento e a Tabela de Factos*/
/*Tabela Dimensao*/

CREATE TABLE Departamento( /*Checked*/
	key_departamento INT PRIMARY KEY CLUSTERED not null,
	designacao VARCHAR(25) null,
	gabinete VARCHAR(25) null
);

/* Tabela Factos*/

Create TABLE Transacoes(
	key_transacoes INT PRIMARY KEY CLUSTERED not null,
	key_departamento INT not null,
	FOREIGN KEY (key_departamento) REFERENCES Departamento(key_departamento),
	);

/* Apagar estas tabelas */
DROP TABLE Transacoes
DROP TABLE Departamento

/* Adicionar Dados de Amostra*/

INSERT INTO Departamento(key_departamento, designacao, gabinete)
VALUES (1, 'Sim', 'SimSim'),
	   (2, 'SAd', 'fagst'),
	   (3, 'gjai', 'oinfo');
  
INSERT INTO Transacoes(key_transacoes, key_departamento)
VALUES (5, 1),
	   (6, 2),
	   (7, 3);


SELECT * FROM Departamento, Transacoes;

IF OBJECT_ID('dbo.Transacoes', 'U') IS NOT NULL DROP TABLE Transacoes
IF OBJECT_ID('dbo.Departamento', 'U') IS NOT NULL DROP TABLE Departamento

